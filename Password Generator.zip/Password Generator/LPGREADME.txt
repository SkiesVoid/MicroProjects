\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
-------------------------------------------------
Thanks for downloading Levi's Password Generator!
-------------------------------------------------
/////////////////////////////////////////////////


               .--.
              /.-. '----------.
              \'-' .--"--""-"-'
               '--'

Instructions:

The number box is a dropdown menu on how many passwords you want generated up to 10.
Just click the box and click a number you want.

After that, just click generate and your passwords are generated.

All passwords are generated on a text box so you may freely edit and/or copy and paste them as you wish.